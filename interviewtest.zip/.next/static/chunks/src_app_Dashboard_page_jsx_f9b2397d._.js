(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_09a0e43f._.js",
  "static/chunks/src_app_dashboard_8476357e._.js",
  "static/chunks/src_app_dashboard_styles_module_scss_module_8f48890e.css"
],
    source: "dynamic"
});
