module.exports = {

"[project]/.next-internal/server/app/api/login/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[project]/src/app/utils/crypto.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "generateMfaCode": (()=>generateMfaCode),
    "generateSecureWord": (()=>generateSecureWord),
    "hashPassword": (()=>hashPassword)
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/crypto [external] (crypto, cjs)");
;
const SECURE_WORD_SECRET = ("TURBOPACK compile-time value", "demo-secure-word-secret-2024") || 'super-secret-key';
const PASSWORD_SECRET = process.env.PASSWORD_SECRET || 'password-key';
function generateSecureWord(username) {
    const raw = username + Date.now();
    return __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["default"].createHmac('sha256', SECURE_WORD_SECRET).update(raw).digest('hex').slice(0, 6);
}
function hashPassword(password) {
    return __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["default"].createHmac('sha256', PASSWORD_SECRET).update(password).digest('hex');
}
function generateMfaCode() {
    // crypto.randomInt is available in Node.js 14+
    const code = __TURBOPACK__imported__module__$5b$externals$5d2f$crypto__$5b$external$5d$__$28$crypto$2c$__cjs$29$__["default"].randomInt(0, 1_000_000).toString().padStart(6, '0');
    return code;
}
}}),
"[project]/src/app/_store.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
// src/app/_store.js
__turbopack_context__.s({
    "credentialStore": (()=>credentialStore),
    "mfaStore": (()=>mfaStore),
    "rateLimitStore": (()=>rateLimitStore),
    "secureStore": (()=>secureStore)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/utils/crypto.js [app-route] (ecmascript)");
;
const secureStore = new Map() // username → { secureWord, issuedAt }
;
const rateLimitStore = new Map() // username → lastRequestTimestamp
;
const mfaStore = new Map() // username → { code, attempts, secret }
;
const credentialStore = new Map() // username → hashedPassword
;
// Pre-populate with test users
credentialStore.set('aaa', (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hashPassword"])('111'));
credentialStore.set('bob', (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hashPassword"])('111'));
credentialStore.set('carol', (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hashPassword"])('111'));
credentialStore.set('dave', (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hashPassword"])('111'));
credentialStore.set('eve', (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hashPassword"])('123'));
}}),
"[project]/src/app/api/login/route.js [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "POST": (()=>POST),
    "runtime": (()=>runtime)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_store$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/_store.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/utils/crypto.js [app-route] (ecmascript)");
;
;
;
const runtime = 'nodejs';
async function POST(request) {
    const { username, password, secureWord } = await request.json();
    const now = Date.now();
    // 1) secure-word check
    const entry = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_store$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["secureStore"].get(username);
    if (!entry || entry.secureWord !== secureWord || now - entry.issuedAt > 60_000) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Invalid or expired secure word.'
        }, {
            status: 400
        });
    }
    // 2) password check
    const expectedHash = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_store$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["credentialStore"].get(username);
    if (!expectedHash) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Unknown user.'
        }, {
            status: 404
        });
    }
    const incomingHash = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["hashPassword"])(password);
    if (incomingHash !== expectedHash) {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: 'Wrong password.'
        }, {
            status: 401
        });
    }
    // 3) issue token + numeric MFA
    const sessionToken = Math.random().toString(36).slice(2);
    const code = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$utils$2f$crypto$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["generateMfaCode"])();
    // store code + reset attempts
    __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f$_store$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mfaStore"].set(username, {
        code,
        attempts: 0
    });
    // return both token and the MFA code for dev/testing
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
        token: sessionToken,
        mfaCode: code
    });
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__8bdc66bd._.js.map